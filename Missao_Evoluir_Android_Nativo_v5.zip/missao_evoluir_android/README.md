# Missão: Evoluir — aplicativo Android nativo

Este é um **projeto Android nativo em Kotlin**. A interface é feita com componentes Android (Activity, TextView, Button, ScrollView, AlertDialog e TimePickerDialog). Não é um site e não usa HTML, JavaScript ou WebView.

## Compatibilidade

- Android 8.0 (API 26) ou superior; configurado para compilar com Android SDK 35 e targetSdk 35 (compatível com Android 15).
- Android Gradle Plugin 8.7.3, Kotlin 2.0.21, JDK 17 e Gradle 8.9.
- Nome do aplicativo: **Missão: Evoluir**.
- ID do aplicativo: `com.missaoevoluir.app`.

## Recursos incluídos

- Personagem com nome editável, XP, níveis e barra de progresso; dados guardados localmente no celular.
- Missão do dia e guia semanal: segunda e quinta calistenia leve; terça e sexta cardio de baixo impacto; quarta e domingo recuperação; sábado livre e opcional.
- Instruções para cada exercício, aquecimento e desaceleração, sem equipamento.
- Progressão em três etapas. As repetições e o volume aumentam gradualmente; uma nova etapa só é liberada após sessões registradas e confirmação consciente. A segunda rodada da etapa final é opcional. XP não aumenta automaticamente o treino.
- Descanso registrado também dá XP; não há punição por pular um treino.
- Central do Sono: permite definir o horário real de acordar em dias de aula e calcula um lembrete para desacelerar e um horário de dormir de referência (10 horas antes da hora de acordar).
- Check-in de bem-estar no primeiro dia do mês, com disposição, qualidade do sono e humor. Não registra peso, calorias ou metas de emagrecimento.
- Notificações de treino às 16h50 nas segundas, terças, quintas e sextas, deixando tempo após a chegada da escola (16h–16h30). Os eventos de treino são adicionados ao calendário às 17h.
- Lembrete noturno calculado pelo horário configurado de acordar.
- Restauração de lembretes depois de reiniciar o celular ou alterar hora/fuso. Se o Android não liberar alarmes exatos, o app usa alarmes aproximados, que podem atrasar.
- Botão para desativar notificações e alarmes.

## Segurança e privacidade

- O app não calcula calorias, não propõe perda de peso e não usa pesagem como pontuação.
- Os exercícios são leves e podem ser interrompidos. Dor, tontura ou falta de ar fora do normal são sinais para parar e avisar um responsável.
- Progresso e check-ins ficam no armazenamento privado do aplicativo. Não há login, conta, servidor ou transmissão de dados.
- Permissões solicitadas: notificações, calendário (ler/escrever), alarmes exatos (acesso especial) e inicialização para restaurar lembretes. Não pede localização, contatos, fotos, câmera ou microfone.

## Gerar e instalar o APK

Este ZIP contém o **código-fonte Android**, não o APK compilado. Para gerar o APK:

1. Instale o Android Studio no computador e tenha JDK 17 e Android SDK Platform 35 disponíveis.
2. Extraia o ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `missao_evoluir_android`.
4. Aguarde a sincronização do Gradle e aceite instalar os componentes solicitados.
5. Escolha **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfira esse APK para o Android 15 e instale. O Android poderá pedir autorização para instalar apps dessa origem.
8. Abra o aplicativo, ajuste o horário em que realmente acorda e toque em **Ativar alarmes e adicionar ao calendário**. Autorize as permissões desejadas.

## Compilação pelo GitHub Actions

O workflow em `.github/workflows/build-apk.yml` compila o APK em cada push nas branches `main` ou `master` e guarda o APK como artefato da execução. Também pode ser iniciado manualmente na aba **Actions** depois que o projeto estiver em um repositório GitHub.
