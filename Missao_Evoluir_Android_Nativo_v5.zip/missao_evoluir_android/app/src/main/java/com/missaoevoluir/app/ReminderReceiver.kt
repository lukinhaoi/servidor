package com.missaoevoluir.app

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Missão: Evoluir"
        val message = intent.getStringExtra("message") ?: "Confira sua missão de hoje."
        val requestCode = intent.getIntExtra("requestCode", 4300)
        val launch = Intent(context, MainActivity::class.java)
        val openApp = PendingIntent.getActivity(
            context, requestCode + 10000, launch,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(context, MainActivity.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(Notification.BigTextStyle().bigText(message))
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .build()

        val allowed = Build.VERSION.SDK_INT < 33 ||
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (allowed) {
            context.getSystemService(NotificationManager::class.java).notify(requestCode, notification)
        }

        val prefs = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.KEY_ENABLED, false)) return

        when (intent.action) {
            ACTION_WORKOUT -> {
                val day = intent.getIntExtra("day", -1)
                if (day != -1) {
                    val nextTitle = if (day == Calendar.MONDAY || day == Calendar.THURSDAY)
                        "Missão de calistenia" else "Missão de movimento"
                    ReminderScheduler.scheduleNextWorkout(context, day, nextTitle)
                }
            }
            ACTION_SLEEP -> {
                val wake = prefs.getString(MainActivity.KEY_WAKE, "05:00") ?: "05:00"
                ReminderScheduler.scheduleSleepReminder(context, wake)
            }
        }
    }

    companion object {
        const val ACTION_WORKOUT = "com.missaoevoluir.app.WORKOUT_REMINDER"
        const val ACTION_SLEEP = "com.missaoevoluir.app.SLEEP_REMINDER"
    }
}
