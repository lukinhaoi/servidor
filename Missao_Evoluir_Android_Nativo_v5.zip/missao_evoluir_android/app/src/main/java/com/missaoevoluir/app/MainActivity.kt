package com.missaoevoluir.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Missão: Evoluir — interface Android nativa.
 * Não utiliza WebView, HTML, JavaScript ou conteúdo de site.
 */
class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    private lateinit var page: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var wakeText: TextView

    private val bg = Color.rgb(9, 15, 29)
    private val panel = Color.rgb(20, 30, 49)
    private val panelSoft = Color.rgb(26, 39, 61)
    private val white = Color.rgb(239, 244, 252)
    private val muted = Color.rgb(167, 181, 203)
    private val mint = Color.rgb(91, 224, 183)
    private val blue = Color.rgb(112, 169, 255)
    private val gold = Color.rgb(255, 207, 112)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        createNotificationChannel()
        renderScreen()
        maybePromptMonthlyCheckin()
        if (prefs.getBoolean(KEY_ENABLED, false)) {
            ReminderScheduler.scheduleAll(this, prefs.getString(KEY_WAKE, DEFAULT_WAKE) ?: DEFAULT_WAKE)
        }
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getBoolean(KEY_ENABLED, false)) {
            ReminderScheduler.scheduleAll(this, prefs.getString(KEY_WAKE, DEFAULT_WAKE) ?: DEFAULT_WAKE)
            refreshPermissionStatus()
        }
    }

    private fun renderScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(32))
        }
        scroll.addView(page)
        setContentView(scroll)

        addText(page, "RPG DE HÁBITOS  •  ANDROID", 11, mint, bold = true, bottom = 8)
        addText(page, "MISSÃO: EVOLUIR", 29, white, bold = true, bottom = 4)
        addText(page, "Seu progresso acontece no seu ritmo.", 14, muted, bottom = 18)

        addCharacterCard()
        addTrainingProgressCard()
        addTodayMissionCard()
        addWeeklyGuideCard()
        addSleepCard()
        addMonthlyCheckinCard()
        addRemindersCard()

        addText(
            page,
            "Lembrete: pare se sentir dor, tontura ou falta de ar incomum. Dias de descanso fazem parte do jogo. Converse com um responsável antes de mudar a dificuldade dos exercícios.",
            12, muted, top = 8, bottom = 8
        )
    }

    private fun addCharacterCard() {
        val card = cardContainer()
        page.addView(card)
        addText(card, "SEU PERSONAGEM", 11, mint, bold = true, bottom = 5)
        val name = prefs.getString(KEY_NAME, "Aventureiro") ?: "Aventureiro"
        addText(card, "⚔  $name", 21, white, bold = true, bottom = 4)
        val xp = prefs.getInt(KEY_XP, 0).coerceAtLeast(0)
        val level = xp / XP_PER_LEVEL + 1
        val levelProgress = xp % XP_PER_LEVEL
        addText(card, "NÍVEL $level   •   $xp XP", 13, gold, bold = true, bottom = 8)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = XP_PER_LEVEL
            progress = levelProgress
            progressTintList = android.content.res.ColorStateList.valueOf(mint)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(46, 59, 78))
        }
        card.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(9)))
        addText(card, "${XP_PER_LEVEL - levelProgress} XP para o próximo nível", 11, muted, top = 6)
        val rename = actionButton("Editar nome", panelSoft, white) {
            val input = android.widget.EditText(this).apply {
                setText(prefs.getString(KEY_NAME, "Aventureiro"))
                setSingleLine(true)
                setTextColor(Color.BLACK)
                hint = "Nome do personagem"
            }
            AlertDialog.Builder(this)
                .setTitle("Nome do personagem")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar") { _, _ ->
                    val newName = input.text.toString().trim().take(20).ifBlank { "Aventureiro" }
                    prefs.edit().putString(KEY_NAME, newName).apply()
                    renderScreen()
                }
                .show()
        }
        card.addView(rename, wrapTop(10))
    }

    private fun addTrainingProgressCard() {
        val stage = prefs.getInt(KEY_TRAINING_STAGE, 0).coerceIn(0, 2)
        val sessions = prefs.getInt(KEY_WORKOUT_COUNT, 0).coerceAtLeast(0)
        val stageName = when (stage) {
            0 -> "Base segura"
            1 -> "Ritmo confortável"
            else -> "Consolidação"
        }
        val card = cardContainer()
        page.addView(card, wrapTop(14))
        addText(card, "EVOLUÇÃO DO TREINO", 11, gold, bold = true, bottom = 5)
        addText(card, "Etapa ${stage + 1}/3 • $stageName", 19, white, bold = true, bottom = 5)
        addText(card, "$sessions sessões de movimento registradas", 13, muted, bottom = 7)
        addText(card, "A dificuldade só muda quando você estiver confortável com a etapa atual. XP e nível do personagem não aumentam o treino automaticamente.", 12, muted)

        val unlockAt = (stage + 1) * 6
        if (stage < 2 && sessions >= unlockAt) {
            val nextLabel = if (stage == 0) "Liberar etapa 2" else "Liberar etapa 3"
            val button = actionButton(nextLabel, mint, bg) {
                AlertDialog.Builder(this)
                    .setTitle("Avançar com segurança?")
                    .setMessage("Você já registrou $sessions sessões. Só avance se os movimentos atuais estiverem confortáveis, sem dor ou tontura, e depois de conversar com um responsável. A nova etapa é opcional; pode continuar na atual.")
                    .setNegativeButton("Continuar nesta etapa", null)
                    .setPositiveButton("Liberar próxima etapa") { _, _ ->
                        prefs.edit().putInt(KEY_TRAINING_STAGE, stage + 1).apply()
                        renderScreen()
                    }
                    .show()
            }
            card.addView(button, wrapTop(10))
        } else if (stage < 2) {
            addText(card, "Próxima etapa disponível depois de mais ${unlockAt - sessions} sessões registradas e uma checagem de conforto.", 11, mint, top = 8)
        } else {
            addText(card, "Última etapa liberada. Não é necessário continuar aumentando a dificuldade.", 11, mint, top = 8)
        }
    }

    private fun addTodayMissionCard() {
        val today = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        val mission = missionFor(today)
        val dateKey = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val doneKey = "done_$dateKey"
        val isDone = prefs.getBoolean(doneKey, false)
        val card = cardContainer()
        page.addView(card, wrapTop(14))
        addText(card, "MISSÃO DE HOJE", 11, blue, bold = true, bottom = 6)
        addText(card, mission.title, 21, white, bold = true, bottom = 6)
        addText(card, mission.summary, 13, muted, bottom = 10)
        mission.details.forEach { addBullet(card, it) }

        val buttonLabel = when {
            isDone -> "Missão registrada ✓"
            mission.optional -> "Registrar atividade opcional  (+10 XP)"
            mission.rest -> "Registrar meu descanso  (+10 XP)"
            else -> "Concluir missão  (+20 XP)"
        }
        val button = actionButton(buttonLabel, if (isDone) Color.rgb(41, 75, 70) else mint, if (isDone) mint else bg) {
            if (!isDone) {
                val reward = if (mission.optional || mission.rest) 10 else 20
                val editor = prefs.edit()
                    .putBoolean(doneKey, true)
                    .putInt(KEY_XP, prefs.getInt(KEY_XP, 0) + reward)
                if (!mission.rest && !mission.optional) {
                    editor.putInt(KEY_WORKOUT_COUNT, prefs.getInt(KEY_WORKOUT_COUNT, 0) + 1)
                }
                editor.apply()
                Toast.makeText(this, "+$reward XP! Boa!", Toast.LENGTH_SHORT).show()
                renderScreen()
            }
        }
        button.isEnabled = !isDone
        card.addView(button, wrapTop(12))
        if (!isDone && !mission.rest && !mission.optional) {
            addText(card, "Depois de concluir, o jogo registra uma sessão de movimento para acompanhar sua evolução. Isso não obriga a aumentar o treino.", 11, muted, top = 7)
        }
        if (mission.rest) {
            addText(card, "Hoje é recuperação. Não é preciso treinar para avançar no jogo.", 12, mint, top = 8)
        }
    }

    private fun addWeeklyGuideCard() {
        val card = cardContainer()
        page.addView(card, wrapTop(14))
        addText(card, "GUIA DA SEMANA", 11, mint, bold = true, bottom = 5)
        addText(card, "Seu mapa de missões", 20, white, bold = true, bottom = 10)

        val rows = listOf(
            "SEGUNDA" to "Calistenia • depois de chegar e descansar",
            "TERÇA" to "Cardio leve dentro de casa",
            "QUARTA" to "Descanso e recuperação",
            "QUINTA" to "Calistenia • depois de chegar e descansar",
            "SEXTA" to "Cardio leve dentro de casa",
            "SÁBADO" to "Livre • movimento divertido opcional",
            "DOMINGO" to "Descanso e recuperação"
        )
        rows.forEachIndexed { index, pair ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(11), dp(9), dp(11), dp(9))
                background = rounded(if (index % 2 == 0) panelSoft else panel, 12)
            }
            addText(row, pair.first, 10, gold, bold = true, bottom = 2)
            addText(row, pair.second, 14, white, bold = true)
            card.addView(row, wrapTop(if (index == 0) 0 else 7))
        }

        val stage = prefs.getInt(KEY_TRAINING_STAGE, 0).coerceIn(0, 2)
        val reps = when (stage) {
            0 -> "6–8"
            1 -> "8–10"
            else -> "8"
        }
        addText(card, "CALISTENIA • ETAPA ${stage + 1}", 11, mint, bold = true, top = 12, bottom = 5)
        addText(card, "Aqueça por 3 minutos. Faça uma rodada: flexão na parede ($reps), sentar e levantar de uma cadeira firme ($reps), elevação de quadril ($reps) e bird dog (4–6 de cada lado). Descanse entre movimentos.", 12, muted)
        if (stage == 2) {
            addText(card, "Uma segunda rodada é opcional e só deve ser feita se a primeira estiver muito confortável, com técnica boa e sem dor. Não precisa completar se estiver cansado.", 12, mint, top = 7)
        }
        val cardio = when (stage) {
            0 -> "8 minutos"
            1 -> "9–10 minutos"
            else -> "10–12 minutos"
        }
        addText(card, "CARDIO LEVE • $cardio", 11, mint, bold = true, top = 10, bottom = 5)
        addText(card, "Marcha no lugar, passos laterais e dança. Pode alternar 30 segundos de marcha um pouco mais rápida com 60 segundos em ritmo tranquilo. Sem correr no máximo, sem saltos e sempre com o chão livre e firme.", 12, muted)
        addText(card, "A progressão depende de conforto, técnica e recuperação, não do peso nem de calorias. Se sentir dor, tontura ou falta de ar fora do normal, pare e avise um responsável.", 12, gold, top = 9)
        addText(card, "Sábado e domingo continuam livres de treino obrigatório. O descanso faz parte do plano.", 12, mint, top = 7)
    }

    private fun addSleepCard() {
        val card = cardContainer()
        page.addView(card, wrapTop(14))
        addText(card, "CENTRAL DO SONO", 11, blue, bold = true, bottom = 5)
        addText(card, "Cuide da energia do personagem", 19, white, bold = true, bottom = 6)
        val wake = prefs.getString(KEY_WAKE, DEFAULT_WAKE) ?: DEFAULT_WAKE
        val bedtime = offsetTime(wake, -600) // referência de 10 horas de sono
        val windDown = offsetTime(wake, -630) // 30 minutos antes de dormir
        wakeText = addText(card, "Hora de acordar configurada: $wake", 14, white, bottom = 4)
        addText(card, "Horário sugerido para dormir: $bedtime", 14, mint, bold = true, bottom = 4)
        addText(card, "Começar a desacelerar: $windDown", 13, muted, bottom = 9)
        addText(card, "A sugestão usa 10 horas como referência inicial. Configure o horário real em que acorda nos dias de aula e combine a rotina de sono com seu responsável.", 12, muted, bottom = 10)
        val timeButton = actionButton("Definir hora que acordo", panelSoft, white) {
            val parts = wake.split(":")
            TimePickerDialog(this, { _, hour, minute ->
                val value = String.format(Locale.US, "%02d:%02d", hour, minute)
                prefs.edit().putString(KEY_WAKE, value).apply()
                if (prefs.getBoolean(KEY_ENABLED, false)) {
                    ReminderScheduler.scheduleAll(this, value)
                }
                renderScreen()
            }, parts.getOrNull(0)?.toIntOrNull() ?: 5, parts.getOrNull(1)?.toIntOrNull() ?: 0, true).show()
        }
        card.addView(timeButton)
    }

    private fun addMonthlyCheckinCard() {
        val monthKey = SimpleDateFormat("yyyyMM", Locale.US).format(Date())
        val saved = prefs.getString("monthly_checkin_$monthKey", null)
        val card = cardContainer()
        page.addView(card, wrapTop(14))
        addText(card, "CHECK-IN MENSAL • DIA 1", 11, gold, bold = true, bottom = 5)
        addText(card, "Como você está se sentindo?", 19, white, bold = true, bottom = 6)
        addText(card, "Registre disposição, sono e humor uma vez por mês. É um diário de bem-estar, não uma avaliação do corpo ou da balança.", 12, muted, bottom = 8)
        addText(card, saved ?: "Nenhum check-in registrado neste mês.", 12, mint, bottom = 9)
        val button = actionButton("Fazer check-in do mês", panelSoft, white) {
            showMonthlyCheckinDialog(monthKey)
        }
        card.addView(button)
    }

    private fun buildCheckinScale(parent: LinearLayout, title: String): RadioGroup {
        addText(parent, title, 13, white, bold = true, top = 8, bottom = 3)
        val group = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
        }
        for (score in 1..5) {
            val option = RadioButton(this).apply {
                id = score
                text = score.toString()
                textSize = 14f
                setTextColor(white)
                buttonTintList = android.content.res.ColorStateList.valueOf(mint)
                isChecked = score == 3
            }
            group.addView(option, RadioGroup.LayoutParams(0, RadioGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        parent.addView(group)
        return group
    }

    private fun showMonthlyCheckinDialog(monthKey: String) {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        addText(content, "Escolha uma nota de 1 a 5 para cada item. Não existe nota certa ou errada.", 13, Color.DKGRAY, bottom = 4)
        val energy = buildCheckinScale(content, "Disposição")
        val sleep = buildCheckinScale(content, "Qualidade do sono")
        val mood = buildCheckinScale(content, "Humor")
        AlertDialog.Builder(this)
            .setTitle("Check-in mensal")
            .setView(content)
            .setNegativeButton("Agora não", null)
            .setPositiveButton("Salvar check-in") { _, _ ->
                val summary = "Disposição ${energy.checkedRadioButtonId.coerceIn(1, 5)}/5 • Sono ${sleep.checkedRadioButtonId.coerceIn(1, 5)}/5 • Humor ${mood.checkedRadioButtonId.coerceIn(1, 5)}/5"
                prefs.edit().putString("monthly_checkin_$monthKey", summary).apply()
                renderScreen()
                Toast.makeText(this, "Check-in salvo. Obrigado por registrar como está!", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun maybePromptMonthlyCheckin() {
        val now = Calendar.getInstance()
        if (now.get(Calendar.DAY_OF_MONTH) != 1) return
        val monthKey = SimpleDateFormat("yyyyMM", Locale.US).format(Date())
        val promptKey = "checkin_prompted_$monthKey"
        if (prefs.getBoolean(promptKey, false)) return
        prefs.edit().putBoolean(promptKey, true).apply()
        page.post { showMonthlyCheckinDialog(monthKey) }
    }

    private fun addRemindersCard() {
        val card = cardContainer()
        page.addView(card, wrapTop(14))
        addText(card, "ALARMES E CALENDÁRIO", 11, gold, bold = true, bottom = 5)
        addText(card, "Deixe o celular lembrar você", 19, white, bold = true, bottom = 7)
        addText(card, "Lembretes de atividade às 16h50 nas segundas, terças, quintas e sextas. O calendário recebe os eventos às 17h. Também há um lembrete noturno calculado pelo seu horário de acordar.", 12, muted, bottom = 10)

        val enabled = prefs.getBoolean(KEY_ENABLED, false)
        val button = actionButton(
            if (enabled) "Desativar alarmes" else "Ativar alarmes e adicionar ao calendário",
            if (enabled) Color.rgb(85, 49, 58) else mint,
            if (enabled) Color.rgb(255, 190, 195) else bg
        ) {
            if (enabled) {
                prefs.edit().putBoolean(KEY_ENABLED, false).apply()
                ReminderScheduler.cancelAll(this)
                statusText.text = "Lembretes desativados. Os eventos já adicionados continuam no calendário; você pode apagá-los pelo app de calendário."
                renderScreen()
            } else {
                prefs.edit().putBoolean(KEY_ENABLED, true).apply()
                requestReminderPermissions()
            }
        }
        card.addView(button)
        statusText = addText(card, statusSummary(), 12, muted, top = 9)
    }

    private fun requestReminderPermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.READ_CALENDAR
        }
        if (checkSelfPermission(Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.WRITE_CALENDAR
        }
        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), REQUEST_SETUP)
        } else {
            finishSetup()
        }
    }

    private fun finishSetup() {
        val notificationsAllowed = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val calendarAllowed = checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED

        if (notificationsAllowed) {
            ReminderScheduler.scheduleAll(this, prefs.getString(KEY_WAKE, DEFAULT_WAKE) ?: DEFAULT_WAKE)
        }
        val calendarMessage = if (calendarAllowed) {
            CalendarEvents.syncWeeklyWorkouts(this)
        } else {
            "Permissão do calendário não concedida; os eventos não foram adicionados."
        }
        prefs.edit().putString(KEY_CALENDAR_STATUS, calendarMessage).apply()

        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).setData(Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                Toast.makeText(this, "Os lembretes poderão chegar com atraso.", Toast.LENGTH_LONG).show()
            }
        }
        renderScreen()
        refreshPermissionStatus()
    }

    private fun refreshPermissionStatus() {
        if (!::statusText.isInitialized) return
        statusText.text = statusSummary()
    }

    private fun statusSummary(): String {
        val enabled = prefs.getBoolean(KEY_ENABLED, false)
        if (!enabled) return "Lembretes desligados. Você pode ativá-los quando quiser."
        val notificationOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val calendarOk = checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED
        val exactOk = Build.VERSION.SDK_INT < 31 || (getSystemService(ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
        val parts = mutableListOf<String>()
        parts += if (notificationOk) "Notificações permitidas." else "Ative as notificações nas configurações do app."
        parts += if (exactOk) "Alarmes pontuais permitidos." else "Alarmes aproximados: podem atrasar."
        if (calendarOk) parts += (prefs.getString(KEY_CALENDAR_STATUS, "Confira o calendário.") ?: "")
        else parts += "Permita o acesso ao calendário para inserir os eventos."
        return parts.joinToString(" ")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_SETUP) finishSetup()
    }

    private fun missionFor(day: Int): DailyMission {
        val stage = prefs.getInt(KEY_TRAINING_STAGE, 0).coerceIn(0, 2)
        val reps = when (stage) {
            0 -> "6–8"
            1 -> "8–10"
            else -> "8"
        }
        return when (day) {
            Calendar.MONDAY, Calendar.THURSDAY -> {
                val details = mutableListOf(
                    "Aqueça por 3 minutos com movimentos leves.",
                    "Flexão na parede: $reps repetições.",
                    "Sentar e levantar de uma cadeira firme: $reps repetições.",
                    "Elevação de quadril: $reps repetições.",
                    "Bird dog: 4–6 de cada lado. Faça uma rodada, descansando quando precisar."
                )
                if (stage == 2) details += "Uma segunda rodada é opcional; só faça se a primeira estiver confortável e sem dor."
                DailyMission("Calistenia leve", "Treino de força tranquilo, dentro de casa.", details, false, false)
            }
            Calendar.TUESDAY, Calendar.FRIDAY -> {
                val cardioMinutes = when (stage) {
                    0 -> "8 minutos"
                    1 -> "9–10 minutos"
                    else -> "10–12 minutos"
                }
                DailyMission(
                    "Movimento e cardio leve", "Movimente-se em ritmo confortável por cerca de $cardioMinutes.",
                    listOf(
                        "Comece com 2 minutos de marcha tranquila no lugar.",
                        "Faça passos laterais por 1–2 minutos.",
                        "Alterne marcha um pouco mais rápida e marcha tranquila, ou escolha dançar.",
                        "Termine desacelerando por 1–2 minutos. Sem saltos e sem correr no máximo."
                    ), false, false
                )
            }
            Calendar.WEDNESDAY, Calendar.SUNDAY -> DailyMission(
                "Dia de recuperação", "Hoje a missão principal é descansar e recuperar a energia.",
                listOf("Não há treino programado.", "Faça suas atividades normais e tente manter um horário tranquilo para dormir."), true, false
            )
            else -> DailyMission(
                "Dia livre", "O sábado é seu. Não existe treino obrigatório hoje.",
                listOf("Se estiver com vontade, escolha algo divertido e leve, como dançar, brincar ou caminhar dentro de casa."), false, true
            )
        }
    }

    private fun addBullet(parent: LinearLayout, text: String) {
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
        }
        val dot = TextView(this).apply {
            text = "•"
            textSize = 16f
            setTextColor(mint)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, dp(8), 0)
        }
        line.addView(dot)
        val body = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(white)
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        line.addView(body, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        parent.addView(line, wrapTop(5))
    }

    private fun cardContainer(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        background = rounded(panel, 18)
    }

    private fun addText(
        parent: LinearLayout,
        value: String,
        size: Int,
        color: Int,
        bold: Boolean = false,
        top: Int = 0,
        bottom: Int = 0,
        end: Int = 0
    ): TextView {
        val view = TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(top)
        lp.bottomMargin = dp(bottom)
        lp.marginEnd = dp(end)
        parent.addView(view, lp)
        return view
    }

    private fun actionButton(label: String, color: Int, textColor: Int, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(textColor)
        background = rounded(color, 13)
        minHeight = dp(48)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        setOnClickListener { onClick() }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun wrapTop(top: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun offsetTime(time: String, offsetMinutes: Int): String {
        val parts = time.split(":")
        val base = (parts.getOrNull(0)?.toIntOrNull() ?: 5) * 60 + (parts.getOrNull(1)?.toIntOrNull() ?: 0)
        val normalized = (base + offsetMinutes + 1440) % 1440
        return String.format(Locale.getDefault(), "%02d:%02d", normalized / 60, normalized % 60)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Lembretes da Missão: Evoluir", NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Lembretes das missões e da rotina de sono." }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private data class DailyMission(
        val title: String,
        val summary: String,
        val details: List<String>,
        val rest: Boolean,
        val optional: Boolean
    )

    companion object {
        const val PREFS = "missao_evoluir_native"
        const val KEY_ENABLED = "reminders_enabled"
        const val KEY_WAKE = "wake_time"
        const val KEY_CALENDAR_STATUS = "calendar_status"
        const val KEY_XP = "xp_total"
        const val KEY_NAME = "character_name"
        const val KEY_TRAINING_STAGE = "training_stage"
        const val KEY_WORKOUT_COUNT = "workout_sessions"
        const val CHANNEL_ID = "missao_evoluir_reminders"
        const val DEFAULT_WAKE = "05:00" // Ajustável pelo usuário na Central do Sono.
        private const val REQUEST_SETUP = 701
        private const val XP_PER_LEVEL = 100
    }
}
