package com.missaoevoluir.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object ReminderScheduler {
    private const val ACTION_WORKOUT = ReminderReceiver.ACTION_WORKOUT
    private const val ACTION_SLEEP = ReminderReceiver.ACTION_SLEEP
    private const val WORKOUT_BASE_ID = 4200
    private const val SLEEP_ID = 4299
    private val workoutDays = listOf(
        Calendar.MONDAY to "Missão de calistenia",
        Calendar.TUESDAY to "Missão de movimento",
        Calendar.THURSDAY to "Missão de calistenia",
        Calendar.FRIDAY to "Missão de movimento"
    )

    fun scheduleAll(context: Context, wakeTime: String) {
        val prefs = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.KEY_ENABLED, false)) return
        workoutDays.forEach { (day, title) -> scheduleNextWorkout(context, day, title) }
        scheduleSleepReminder(context, wakeTime)
    }

    fun cancelAll(context: Context) {
        workoutDays.forEach { (day, _) -> cancel(context, WORKOUT_BASE_ID + day, ACTION_WORKOUT) }
        cancel(context, SLEEP_ID, ACTION_SLEEP)
    }

    fun scheduleNextWorkout(context: Context, day: Int, title: String) {
        val now = Calendar.getInstance()
        val next = (now.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 16)
            set(Calendar.MINUTE, 50)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            while (get(Calendar.DAY_OF_WEEK) != day || timeInMillis <= now.timeInMillis) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        schedule(context, WORKOUT_BASE_ID + day, next.timeInMillis, ACTION_WORKOUT, title,
            "São 16h50. Descanse e veja sua missão no app; não precisa treinar se não estiver bem.", day)
    }

    fun scheduleSleepReminder(context: Context, wakeTime: String) {
        val pieces = wakeTime.split(":")
        val wakeHour = pieces.getOrNull(0)?.toIntOrNull() ?: 5
        val wakeMinute = pieces.getOrNull(1)?.toIntOrNull() ?: 0
        val wakeMinutes = wakeHour * 60 + wakeMinute
        val reminderMinutes = (wakeMinutes - 630 + 1440) % 1440 // 10h de sono + 30 min para desacelerar
        val hour = reminderMinutes / 60
        val minute = reminderMinutes % 60
        val now = Calendar.getInstance()
        val next = (now.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
        }
        schedule(context, SLEEP_ID, next.timeInMillis, ACTION_SLEEP,
            "Hora de desacelerar", "Guarde as telas e comece sua rotina tranquila para dormir.", -1)
    }

    private fun schedule(context: Context, requestCode: Int, atMillis: Long, action: String, title: String, message: String, day: Int) {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            this.action = action
            putExtra("title", title)
            putExtra("message", message)
            putExtra("day", day)
            putExtra("requestCode", requestCode)
        }
        val pending = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && manager.canScheduleExactAlarms()) {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pending)
        } else {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pending)
        }
    }

    private fun cancel(context: Context, requestCode: Int, action: String) {
        val intent = Intent(context, ReminderReceiver::class.java).apply { this.action = action }
        val pending = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        ) ?: return
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        manager.cancel(pending)
        pending.cancel()
    }
}
