package com.missaoevoluir.app

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract
import java.util.Calendar
import java.util.TimeZone

object CalendarEvents {
    private const val MARKER = "[MISSÃO_EVOLUIR_SEMANAL_V1]"

    fun syncWeeklyWorkouts(context: Context): String {
        return try {
        val resolver = context.contentResolver
        val calendarId = findWritableCalendar(context) ?: return "Não encontrei um calendário disponível para escrita. Confira se há um app de calendário configurado."

        // Remove only this app's previous recurring series, preventing duplicates on reactivation.
        val old = resolver.query(
            CalendarContract.Events.CONTENT_URI,
            arrayOf(CalendarContract.Events._ID),
            "${CalendarContract.Events.DESCRIPTION} LIKE ?",
            arrayOf("%$MARKER%"),
            null
        )
        old?.use { cursor ->
            while (cursor.moveToNext()) {
                val id = cursor.getLong(0)
                resolver.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id), null, null)
            }
        }

        val sessions = listOf(
            Triple(Calendar.MONDAY, "Missão: calistenia em casa", "Depois da escola e de um tempo para descansar: calistenia leve. Confira a etapa atual no app. A atividade é opcional se não estiver se sentindo bem."),
            Triple(Calendar.TUESDAY, "Missão: cardio leve em casa", "Depois da escola e de um tempo para descansar: marcha no lugar, passos laterais ou dança em ritmo confortável."),
            Triple(Calendar.THURSDAY, "Missão: calistenia em casa", "Depois da escola e de um tempo para descansar: calistenia leve. Confira a etapa atual no app. A atividade é opcional se não estiver se sentindo bem."),
            Triple(Calendar.FRIDAY, "Missão: cardio leve em casa", "Depois da escola e de um tempo para descansar: marcha no lugar, passos laterais ou dança em ritmo confortável.")
        )
        val zone = TimeZone.getDefault()
        var count = 0
        for ((weekday, title, details) in sessions) {
            val start = nextOccurrence(weekday, 17, 0)
            val values = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calendarId)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DESCRIPTION, "$details\n$MARKER")
                put(CalendarContract.Events.DTSTART, start.timeInMillis)
                put(CalendarContract.Events.DURATION, "PT25M")
                put(CalendarContract.Events.EVENT_TIMEZONE, zone.id)
                put(CalendarContract.Events.RRULE, "FREQ=WEEKLY;BYDAY=${weekdayCode(weekday)}")
                put(CalendarContract.Events.AVAILABILITY, CalendarContract.Events.AVAILABILITY_FREE)
                put(CalendarContract.Events.ACCESS_LEVEL, CalendarContract.Events.ACCESS_PRIVATE)
            }
            if (resolver.insert(CalendarContract.Events.CONTENT_URI, values) != null) count++
        }
        if (count == 4) "4 eventos semanais foram adicionados ao calendário, às 17h (seg, ter, qui e sex)." else "Adicionei $count de 4 eventos. Confira seu calendário."
        } catch (_: SecurityException) {
            "O Android não autorizou a escrita no calendário. Confira a permissão e tente novamente."
        } catch (_: Exception) {
            "Não consegui acessar o calendário deste aparelho. Você pode conferir se há um calendário configurado."
        }
    }

    private fun findWritableCalendar(context: Context): Long? {
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.IS_PRIMARY,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
            CalendarContract.Calendars.VISIBLE
        )
        val cursor = context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            "${CalendarContract.Calendars.VISIBLE}=1 AND ${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL}>=?",
            arrayOf(CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR.toString()),
            "${CalendarContract.Calendars.IS_PRIMARY} DESC"
        ) ?: return null
        cursor.use {
            return if (it.moveToFirst()) it.getLong(0) else null
        }
    }

    private fun nextOccurrence(day: Int, hour: Int, minute: Int): Calendar {
        val now = Calendar.getInstance()
        return (now.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            while (get(Calendar.DAY_OF_WEEK) != day || timeInMillis <= now.timeInMillis) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }
    }

    private fun weekdayCode(day: Int): String = when (day) {
        Calendar.MONDAY -> "MO"
        Calendar.TUESDAY -> "TU"
        Calendar.THURSDAY -> "TH"
        Calendar.FRIDAY -> "FR"
        else -> "MO"
    }
}
