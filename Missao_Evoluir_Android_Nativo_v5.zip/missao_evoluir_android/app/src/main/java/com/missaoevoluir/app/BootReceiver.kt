package com.missaoevoluir.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(MainActivity.KEY_ENABLED, false)) {
            val wakeTime = prefs.getString(MainActivity.KEY_WAKE, "05:00") ?: "05:00"
            ReminderScheduler.scheduleAll(context, wakeTime)
        }
    }
}
